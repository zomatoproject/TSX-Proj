const request = require('supertest');
const app = require('../app'); // Make sure to export your app in app.js

describe('Mentor API', () => {
  it('should sign in a mentor with valid credentials', async () => {
    const res = await request(app)
      .post('/mentors/signin')
      .send({
        email: 'mentor@example.com',
        password: 'password123',
      });
    expect(res.statusCode).toEqual(200);
    expect(res.body).toHaveProperty('token');
  });

  it('should return 401 for invalid credentials', async () => {
    const res = await request(app)
      .post('/mentors/signin')
      .send({
        email: 'mentor@example.com',
        password: 'wrongpassword',
      });
    expect(res.statusCode).toEqual(401);
  });
});
