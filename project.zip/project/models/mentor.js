const db = require('../config/db');
const bcrypt = require('bcryptjs');

class Mentor {
  static findMentorByEmail(email) {
    return new Promise((resolve, reject) => {
      db.query('SELECT * FROM mentors WHERE email = ?', [email], (err, results) => {
        if (err) reject(err);
        resolve(results[0]);
      });
    });
  }
}

module.exports = Mentor;
