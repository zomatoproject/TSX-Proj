const express = require('express');
const router = express.Router();
const mentorController = require('../controllers/mentorController');
const auth = require('../middlewares/auth');

// Sign In
router.post('/signin', mentorController.signIn);

// Get Mentor Details
router.get('/:id', auth, mentorController.getMentorDetails); // Secure this route

module.exports = router;

