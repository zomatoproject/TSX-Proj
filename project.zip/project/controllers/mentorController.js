const bcrypt=require('bcryptjs');
const Mentor = require('../models/mentor');
const jwt = require('jsonwebtoken');

// Sign in a mentor
exports.signIn = async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: 'Email and password are required.' });
  }

  try {
    const mentor = await Mentor.findMentorByEmail(email);

    if (!mentor || !bcrypt.compareSync(password, mentor.password)) {
      return res.status(401).json({ message: 'Invalid email or password.' });
    }

    const token = jwt.sign({ id: mentor.id }, process.env.JWT_SECRET, {
      expiresIn: '24h',
    });
    res.status(200).json({ token });
    console.log('signIn Successful');
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error signing in mentor.', error: err });
  }
};

// Get mentor details
exports.getMentorDetails = async (req, res) => {
  const mentorId = req.params.id;

  try {
    const mentor = await Mentor.findMentorById(mentorId); // You'll need to add this method
    if (!mentor) {
      return res.status(404).json({ message: 'Mentor not found.' });
    }
    res.status(200).json(mentor);
  } catch (err) {
    res.status(500).json({ message: 'Error retrieving mentor details.', error: err });
  }
};
